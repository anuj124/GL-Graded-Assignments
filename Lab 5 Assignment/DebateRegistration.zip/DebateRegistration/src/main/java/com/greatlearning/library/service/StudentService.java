package com.greatlearning.library.service;

import java.util.List;

import com.greatlearning.library.entity.Student;

public interface StudentService {

	public List<Student> findAll();

	public Student findById(int studentId);

	public void save(Student theStudent);

	public void deleteById(int studentId);

}
